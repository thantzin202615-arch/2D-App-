2D Lottery App - Source ZIP

ပါဝင်သည်
- public/index.html : အသုံးပြုသူစာမျက်နှာ (00 မှ 99 ဂဏန်းရွေးပြီးမှ ငွေပမာဏထည့်ရန်)
- public/admin.html : Admin dashboard
- server.js : Online API နှင့် SQLite database
- capacitor.config.json : Android wrapper အတွက် setting

ဖုန်းကနေ စမ်းရန်
1. ZIP ကို Extract လုပ်ပါ။
2. Online တင်ရန် Node.js hosting တစ်ခုတွင် project ဖိုင်များတင်ပါ။
3. Build command မလိုပါ။ Start command: npm start
4. Environment variable ADMIN_PASSWORD ကို မိမိစကားဝှက်အသစ်ဖြင့် သတ်မှတ်ပါ။
5. SQLite database ဖိုင် lottery.db ကို persistent storage ရှိသောနေရာတွင်ထားပါ။

Admin လိပ်စာ: https://သင့်-website/admin
Default admin password: 123456
လုံခြုံရေးအတွက် online မတင်မီ ADMIN_PASSWORD ကို မဖြစ်မနေပြောင်းပါ။

အရေးကြီး
- ဤ ZIP သည် source project ဖြစ်ပြီး APK binary မဟုတ်ပါ။
- APK ထုတ်ရန် Android build environment (Android Studio/Gradle) လိုအပ်သည်။
- Hosting ပေါ်တွင် persistent disk မရှိလျှင် SQLite စာရင်းပျောက်နိုင်သည်။
- အမှန်တကယ်ငွေကြေးလောင်းကြေးအသုံးပြုမည်ဆိုပါက သက်ဆိုင်ရာဒေသဥပဒေများကို စစ်ဆေးပါ။
