const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '123456';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database(process.env.DB_PATH || './lottery.db');
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS bets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number TEXT NOT NULL,
    amount INTEGER NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  )`);
  db.run(`INSERT OR IGNORE INTO settings(key,value) VALUES ('open','1')`);
});

const getSetting = (key) => new Promise((resolve, reject) =>
  db.get('SELECT value FROM settings WHERE key=?', [key], (e, r) => e ? reject(e) : resolve(r?.value))
);
const adminOnly = (req, res, next) => {
  if (req.headers['x-admin-password'] !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Admin password မမှန်ပါ' });
  }
  next();
};

app.get('/api/status', async (req, res) => {
  try { res.json({ open: (await getSetting('open')) === '1' }); }
  catch { res.status(500).json({ error: 'Server error' }); }
});

app.post('/api/bets', async (req, res) => {
  try {
    if ((await getSetting('open')) !== '1') return res.status(403).json({ error: 'လက်ခံချိန်ပိတ်ထားပါသည်' });
    const number = String(req.body.number ?? '');
    const amount = Number(req.body.amount);
    if (!/^\d{2}$/.test(number)) return res.status(400).json({ error: 'ဂဏန်း ၂ လုံးရွေးပါ' });
    if (!Number.isSafeInteger(amount) || amount < 1 || amount > 100000000) {
      return res.status(400).json({ error: 'ငွေပမာဏ မှန်ကန်စွာထည့်ပါ' });
    }
    db.run('INSERT INTO bets(number,amount) VALUES(?,?)', [number, amount], function(err) {
      if (err) return res.status(500).json({ error: 'သိမ်းဆည်းမရပါ' });
      res.json({ ok: true, id: this.lastID, message: 'စာရင်းသွင်းပြီးပါပြီ' });
    });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

app.post('/api/admin/login', (req, res) => {
  if (String(req.body.password || '') !== ADMIN_PASSWORD) return res.status(401).json({ error: 'စကားဝှက်မမှန်ပါ' });
  res.json({ ok: true });
});
app.get('/api/admin/bets', adminOnly, (req, res) => {
  db.all('SELECT id,number,amount,created_at FROM bets ORDER BY id DESC LIMIT 500', [], (e, rows) => {
    if (e) return res.status(500).json({ error: 'စာရင်းဖတ်မရပါ' });
    res.json(rows);
  });
});
app.get('/api/admin/summary', adminOnly, (req, res) => {
  db.get('SELECT COUNT(*) AS count, COALESCE(SUM(amount),0) AS total FROM bets', [], (e, row) => {
    if (e) return res.status(500).json({ error: 'စာရင်းဖတ်မရပါ' });
    res.json(row);
  });
});
app.post('/api/admin/open', adminOnly, (req, res) => {
  db.run("UPDATE settings SET value=? WHERE key='open'", [req.body.open ? '1' : '0'], e => {
    if (e) return res.status(500).json({ error: 'ပြင်ဆင်မရပါ' });
    res.json({ ok: true });
  });
});
app.post('/api/admin/reset', adminOnly, (req, res) => {
  db.run('DELETE FROM bets', e => {
    if (e) return res.status(500).json({ error: 'ဖျက်မရပါ' });
    res.json({ ok: true });
  });
});

app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Lottery app running on port ${PORT}`));
